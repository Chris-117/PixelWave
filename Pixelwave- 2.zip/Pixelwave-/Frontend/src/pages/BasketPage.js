import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './BasketPage.css';
import jwt_decode from 'jwt-decode';
import { useNavigate } from 'react-router-dom';


const BasketPage = () => {
  const [basketItems, setBasketItems] = useState([]);
  const navigate = useNavigate();
  useEffect(() => {
    const fetchBasketItems = async () => {
      try {
        const token = localStorage.getItem('token');
        let customerId = null;

        if (token) {
          const decodedToken = jwt_decode(token);
          customerId = decodedToken.id;
        }

        const response = await axios.get(`http://localhost:8080/orderItems/customer/${customerId}`);
        const basketItemsData = response.data;
        setBasketItems(basketItemsData);
        console.log(basketItemsData.name)
      } catch (error) {
        console.error('Error fetching basket items:', error);
      }
    };

    fetchBasketItems();
  }, []);

  const removeFromBasket = async (item) => {
    try {
        console.log(item.id)
      const response = await axios.delete(`http://localhost:8080/orderItems/customer/${1}`);

      if (response.status === 200) {
        //const updatedItems = basketItems.filter((item) => item.id !== itemId);
        //setBasketItems(updatedItems);
      } else {
        console.error('Error removing item from basket:', response.status);
      }
    } catch (error) {
      console.error('Error removing item from basket:', error);
    }
  };

  const updateQuantity = (itemId, quantity) => {
    // Find the item in the basketItems array and update its quantity
    const updatedItems = basketItems.map((item) => {
      if (item.id === itemId) {
        return {
          ...item,
          quantity: quantity,
        };
      }
      return item;
    });

    setBasketItems(updatedItems);
  };

  const handleUpdate = async (item) => {
    try {
      const response = await axios.put(`http://localhost:8080/orderItems/customer/${3}`, {
        quantity: item.quantity,
      });

      if (response.status === 200) {
        console.log('Item quantity updated successfully');
      } else {
        console.error('Error updating item quantity:', response.status);
      }
    } catch (error) {
      console.error('Error updating item quantity:', error);
    }
  };

  const handleCheckout = () => {
    navigate('/checkout');
    console.log('Checkout clicked');
  };

  return (
    <div className="basket-container">
      <h2>Your Basket</h2>
      {basketItems.length > 0 ? (
        <ul className="basket-items">
          {basketItems.map((item) => (
            <li key={item.id} className="basket-item">
              <div className="item-details">
                <h3>{item.name}</h3>
                <p>Price: £{item.price}</p>
                <p>
                  Quantity:
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.id, e.target.value)}
                  />
                </p>
              </div>
              <button onClick={() => removeFromBasket(item)}>Remove</button>
              <button onClick={() => handleUpdate(item)}>Update</button>
            </li>
          ))}
        </ul>
      ) : (
        <p>Your basket is empty.</p>
      )}
      <button onClick={handleCheckout}>Checkout</button>
    </div>
  );
};

export default BasketPage;