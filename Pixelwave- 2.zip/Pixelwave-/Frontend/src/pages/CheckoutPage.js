import React, { useEffect, useState } from 'react';
import axios from 'axios';

const OrderDetails = () => {
  const [order, setOrder] = useState(null);

  useEffect(() => {
    const fetchOrderDetails = async () => {
      try {
        const response = await axios.get('http://localhost:8080/orders/1'); 
        setOrder(response.data);
      } catch (error) {
        console.error(error);
      }
    };

    fetchOrderDetails();
  }, []);

  return (
    <div>
      {order ? (
        <div>
          <h2>Order Details</h2>
          <p>Order ID: {order.orderId}</p>
          <p>Order Items ID: {order.orderItemsId}</p>
          <p>Date: {order.date}</p>
          <p>Payment Status: {order.paymentStatus}</p>
          <p>Customer ID: {order.customerId}</p>
          <p>Delivery Address: {order.deliveryAddress}</p>
          <p>Total Price: {order.totalPrice}</p>
        </div>
      ) : (
        <p>Loading order details...</p>
      )}
    </div>
  );
};

export default OrderDetails;