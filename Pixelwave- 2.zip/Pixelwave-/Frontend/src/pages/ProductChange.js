import axios from 'axios';
import React, { useState, useEffect } from 'react';
import './ProductChange.css'

const AddProductForm = () => {
  const [product, setProduct] = useState({
    name: '',
    price: '',
    description: '',
    image: '',
    productType: ''
  });
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (successMessage) {
      const timeout = setTimeout(() => {
        setSuccessMessage('');
      }, 3000);

      return () => clearTimeout(timeout);
    }
  }, [successMessage]);

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:8080/products/', product);

      if (response.status === 201) {
        setSuccessMessage('Product added successfully!');
        setProduct({
          name: '',
          price: '',
          description: '',
          image: '',
          productType: ''
        });
      } else {
        setSuccessMessage('');
        // Handle error
      }
    } catch (error) {
      setSuccessMessage('');
      // Handle error
    }
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setProduct((prevProduct) => ({ ...prevProduct, [name]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setProduct((prevProduct) => ({ ...prevProduct, image: file }));
  };

  return (
    <div>
      <h2>Add Product</h2>
      {successMessage && <p>{successMessage}</p>}
      <form onSubmit={handleFormSubmit}>
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          id="name"
          name="name"
          value={product.name}
          onChange={handleInputChange}
        />

        <label htmlFor="price">Price:</label>
        <input
          type="text"
          id="price"
          name="price"
          value={product.price}
          onChange={handleInputChange}
        />

        <label htmlFor="description">Description:</label>
        <textarea
          id="description"
          name="description"
          value={product.description}
          onChange={handleInputChange}
        />

        <label htmlFor="image">Image:</label>
        <input
          type="file"
          id="image"
          accept="image/*"
          onChange={handleImageChange}
        />

        <label htmlFor="product">Product:</label>
        <select
          id="product"
          name="productType"
          value={product.productType}
          onChange={handleInputChange}
        >
          <option value="">Select a product</option>
          <option value="HEADSET">Headset</option>
          <option value="KEYBOARD">Keyboard</option>
          <option value="MOUSE">Mouse</option>
          <option value="MONITOR">Monitor</option>
        </select>

        <button type="submit">Add Product</button>
      </form>
    </div>
  );
};

export default AddProductForm;