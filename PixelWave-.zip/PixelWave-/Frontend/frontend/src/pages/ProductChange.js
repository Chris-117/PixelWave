import axios from 'axios';
import React, { useState, useEffect } from 'react';
import './ProductChange.css'
import { Link, useNavigate } from 'react-router-dom';
import jwt_decode from 'jwt-decode';


const AddProductForm = () => {
  const [product, setProduct] = useState({
    name: '',
    price: '',
    description: '',
    image: '',
    productType: ''
  });
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const checkAdminAccess = async () => {
      try {
        const token = localStorage.getItem('token');
        if (token) {
          const decodedToken = jwt_decode(token);
          if (!decodedToken.admin) {
            // Redirect to a page indicating unauthorized access
            navigate('/unauthorized');
          }
        } else {
          // Redirect to the login page if no token is found
          navigate('/signUp');
        }
      } catch (error) {
        console.error('Error checking admin access:', error);
      }
    };

    checkAdminAccess();
  }, []);

  useEffect(() => {
    if (successMessage) {
      const timeout = setTimeout(() => {
        setSuccessMessage('');
      }, 3000);

      return () => clearTimeout(timeout);
    }
  }, [successMessage]);

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:8080/products/', product);

      if (response.status === 201) {
        setSuccessMessage('Product added successfully!');
        setProduct({
          name: '',
          price: '',
          description: '',
          image: '',
          productType: ''
        });
      } else {
        setSuccessMessage('Error adding Product');
        // Handle error
      }
    } catch (error) {
      setSuccessMessage('Error adding Product');
      // Handle error
    }
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setProduct((prevProduct) => ({ ...prevProduct, [name]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setProduct((prevProduct) => ({ ...prevProduct, image: file }));
  };

  const handleUpdateProduct = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.put(`http://localhost:8080/products/${product.id}`, product);

      if (response.status === 200) {
        setSuccessMessage('Product updated successfully!');
        // Handle success
      } else {
        setSuccessMessage('Error updating Product');
        // Handle error
      }
    } catch (error) {
      setSuccessMessage('Error updating Product');
      // Handle error
    }
  };

  return (
    <div>
      <h2>Add/Update Product</h2>
      {successMessage && <p>{successMessage}</p>}
      <form onSubmit={handleFormSubmit}>
        {/* Product name input */}
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          id="name"
          name="name"
          value={product.name}
          onChange={handleInputChange}
        />

        {/* Product price input */}
        <label htmlFor="price">Price:</label>
        <input
          type="text"
          id="price"
          name="price"
          value={product.price}
          onChange={handleInputChange}
        />

        {/* Product description input */}
        <label htmlFor="description">Description:</label>
        <textarea
          id="description"
          name="description"
          value={product.description}
          onChange={handleInputChange}
        />

        {/* Product image input */}
        <label htmlFor="image">Image:</label>
        <input
          type="file"
          id="image"
          accept="image/*"
          onChange={handleImageChange}
        />

        {/* Product type select */}
        <label htmlFor="product">Product:</label>
        <select
          id="product"
          name="productType"
          value={product.productType}
          onChange={handleInputChange}
        >
          <option value="">Select a product</option>
          <option value="HEADSET">Headset</option>
          <option value="KEYBOARD">Keyboard</option>
          <option value="MOUSE">Mouse</option>
          <option value="MONITOR">Monitor</option>
        </select>

        {/* Add Product button */}
        <button type="submit">Add Product</button>
      </form>

      {/* Update Product form */}
      <form onSubmit={handleUpdateProduct}>
        {/* Product ID input */}
        <label htmlFor="id">Product ID:</label>
        <input
          type="text"
          id="id"
          name="id"
          value={product.id}
          onChange={handleInputChange}
        />

        {/* Update Product button */}
        <button type="submit">Update Product</button>
      </form>
    </div>
  );
};

export default AddProductForm;
