import React from 'react';
import Name from '../components/Name';

const SignUpPageComp = () => {
    return (
        <div className = "comp">
            <h1> Account Successfully registed!</h1>
            <h2>Welcome:</h2>
            <Name/>
        </div>
    )
};
export default SignUpPageComp;