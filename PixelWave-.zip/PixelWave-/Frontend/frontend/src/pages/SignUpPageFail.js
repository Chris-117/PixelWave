import React from 'react';
import Name from '../components/Name';

const SignUpPageFail = () => {
    return (
        <div >
            <h1>Failure</h1>
        </div>
    )
};
export default SignUpPageFail;