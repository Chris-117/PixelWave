#INSERT INTO Product (product_id, name, price, description, image, stock) VALUES (1, 'Product 1', '10.99', 'Description 1', 'image1.jpg', 50);
#INSERT INTO Product (product_id, name, price, description, image, stock) VALUES (2, 'Product 2', '19.99', 'Description 2', 'image2.jpg', 25);
#INSERT INTO Product (product_id, name, price, description, image, stock) VALUES (3, 'Product 3', '5.99', 'Description 3', 'image3.jpg', 100);
#INSERT INTO Product (product_id, name, price, description, image, stock) VALUES (4, 'Product 4', '8.99', 'Description 4', 'image4.jpg', 75);
#INSERT INTO Product (product_id, name, price, description, image, stock) VALUES (5, 'Product 5', '12.99', 'Description 5', 'image5.jpg', 60);
#INSERT INTO Customer (customer_id, name, surname, email, admin, card_number, expiry, address, postcode) VALUES (1, 'John', 'Doe', 'johndoe@example.com', 1, '1234567890123456', '2023-12-31', '123 Main St', '12345');