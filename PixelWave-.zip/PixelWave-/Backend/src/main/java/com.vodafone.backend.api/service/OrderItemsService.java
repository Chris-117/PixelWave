package com.vodafone.backend.api.service;

public interface OrderItemsService {
}
