package com.vodafone.backend.api.domain;

public enum ProductType {
    MOUSE,
    KEYBOARD,
    HEADSET,
    MONITOR
}
